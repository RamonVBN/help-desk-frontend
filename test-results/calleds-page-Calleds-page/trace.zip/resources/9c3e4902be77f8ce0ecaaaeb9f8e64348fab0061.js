(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_027b5186._.js",
  "static/chunks/node_modules_af2380ec._.js"
],
    source: "dynamic"
});
