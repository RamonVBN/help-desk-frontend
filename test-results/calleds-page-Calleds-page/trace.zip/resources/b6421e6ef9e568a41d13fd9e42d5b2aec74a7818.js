(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_fa4e7225._.js",
  "static/chunks/node_modules_1ef2a027._.js"
],
    source: "dynamic"
});
