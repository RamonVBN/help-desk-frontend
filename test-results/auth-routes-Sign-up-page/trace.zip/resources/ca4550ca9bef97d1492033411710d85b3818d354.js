(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c319da63._.js",
  "static/chunks/src_components_queryClientProviderWrapper_tsx_94dc4f99._.js",
  "static/chunks/src_app_globals_91e4631d.css"
],
    source: "dynamic"
});
