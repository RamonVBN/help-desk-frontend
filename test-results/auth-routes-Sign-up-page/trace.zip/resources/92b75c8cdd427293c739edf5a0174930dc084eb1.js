(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_zod_v4_d4e4039c._.js",
  "static/chunks/node_modules_axios_3c0c0f8e._.js",
  "static/chunks/node_modules_b9c11102._.js",
  "static/chunks/src_d10534c9._.js"
],
    source: "dynamic"
});
